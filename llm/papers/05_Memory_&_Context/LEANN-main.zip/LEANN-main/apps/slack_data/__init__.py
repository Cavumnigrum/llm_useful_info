# Slack MCP data integration for LEANN
