"""iMessage data processing module."""
