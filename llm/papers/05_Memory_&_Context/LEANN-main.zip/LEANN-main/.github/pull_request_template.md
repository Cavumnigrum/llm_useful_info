## What does this PR do?

<!-- Brief description of your changes -->

## Related Issues

Fixes #

## Checklist

- [ ] Tests pass (`uv run pytest`)
- [ ] Code formatted (`ruff format` and `ruff check`)
- [ ] Pre-commit hooks pass (`pre-commit run --all-files`)
